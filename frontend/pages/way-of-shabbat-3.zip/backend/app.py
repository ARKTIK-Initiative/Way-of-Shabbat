
from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

@app.route('/api/search', methods=['GET'])
def search_torah():
    query = request.args.get('query')
    url = f"https://www.sefaria.org/api/texts/{query}"
    response = requests.get(url)

    if response.status_code == 200:
        return jsonify(response.json())
    else:
        return jsonify({'error': 'Unable to fetch text'}), 500

if __name__ == '__main__':
    app.run(debug=True)
